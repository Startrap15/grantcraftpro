import React from 'react';
import ResourcesContent from '../components/Resources';

export default function Resources() {
  return (
    <div className="pt-16">
      <ResourcesContent />
    </div>
  );
}